export interface Librarian {
  uname: string;
  pass: string;
}

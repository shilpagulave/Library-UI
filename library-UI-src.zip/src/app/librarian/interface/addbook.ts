export interface Addbook {
  id: string;
  name: string;
  author: string;
  publication: string;
  price: number;
}

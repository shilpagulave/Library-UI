import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment as env } from "../../../environments/environment";
import { Addbook } from "../interface/addbook";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class BookService {
  path = env.serverURL + "/books";
  constructor(private http: HttpClient) {}
  addbooks(books: Addbook): Observable<Addbook> {
    return this.http.post<Addbook>(this.path + "/create", books);
  }
  getbooks(): Observable<Addbook[]> {
    return this.http.get<Addbook[]>(this.path + "/display");
  }
  deleterecord(id: any): Observable<any> {
    alert(id);
    return this.http.delete<any>(this.path + "/delete/" + id);
  }
}

import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment as env } from "../../../environments/environment";
import { Librarian } from "../interface/librarian";
import { HttpHeaders, HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class LibrarianService {
  path = env.serverURL + "/librarian";
  constructor(private http: HttpClient) {}

  labregistration(student: Librarian): Observable<Librarian> {
    return this.http.post<Librarian>(this.path + "/create", student);
  }

  // lablogin(librarian: Librarian): Observable<any> {
  //   const httpOptions = {
  //     headers: new HttpHeaders({ "Content-Type": "application/json" }),
  //     observe: "response" as "response"
  //   };

  //   return this.http.post<Librarian>(
  //     this.path + "/login",
  //     librarian,
  //     httpOptions
  //   );
  // }
  lablogin(librarian: Librarian): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ "Content-Type": "application/json" }),
      observe: "response" as "response"
    };

    return this.http.post<Librarian>(
      this.path + "/login",
      librarian,
      httpOptions
    );
  }
}

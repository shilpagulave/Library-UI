import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { LibrarianService } from "../../services/librarian.service";

@Component({
  selector: "app-lragistration",
  templateUrl: "./lragistration.component.html",
  styleUrls: ["./lragistration.component.css"]
})
export class LragistrationComponent implements OnInit {
  constructor(private fb: FormBuilder, private lab: LibrarianService) {}

  frm: FormGroup;

  ngOnInit() {
    this.frm = this.fb.group({
      name: ["", Validators.required],
      // address: ["", Validators.required],
      mobile: ["", Validators.compose([Validators.pattern[0 - 9]])],
      email: ["", Validators.required],
      pass: ["", Validators.required]
    });
  }
  register() {
    this.lab.labregistration(this.frm.value).subscribe(
      data => {
        console.log("librarian:" + JSON.stringify(data));
        if (data) {
          alert("Librarian register sucessfully");
        } else {
          alert("could not register");
        }
      },
      err => {
        console.log("Librarian Error" + JSON.stringify(err));
        alert("could not register ! server problem");
      }
    );
  }
}

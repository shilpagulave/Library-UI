import {
  AfterViewInit,
  Component,
  OnInit,
  ViewChild,
  ChangeDetectorRef
} from "@angular/core";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTable, MatTableDataSource } from "@angular/material/table";
// import { AddbooksDataSource, AddbooksItem } from "./addbooks-datasource";
import { MatDialog } from "@angular/material";
import { AddbookpopupComponent } from "../addbookpopup/addbookpopup.component";
import { BookService } from "../../services/book.service";
export interface Addbook {
  id: string;
  name: string;
  author: string;
  publication: string;
  price: number;
}

@Component({
  selector: "app-addbooks",
  templateUrl: "./addbooks.component.html",
  styleUrls: ["./addbooks.component.css"]
})
export class AddbooksComponent implements OnInit {
  displayedColumns: string[] = [
    "srno",
    "id",
    "name",
    "author",
    "publication",
    "price",
    "action"
  ];
  dataSource: MatTableDataSource<Addbook>;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    public matdial: MatDialog,
    private service: BookService,
    private changeDetectorRefs: ChangeDetectorRef
  ) {}

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  teachDS: any;
  user: any;
  data: any;
  ngOnInit() {
    this.refresh();
  }

  openDialog() {
    this.matdial
      .open(AddbookpopupComponent, {
        data: { user: this.user }
      })
      .afterClosed()
      .subscribe(result => {
        this.refresh();
      });
  }

  refresh() {
    this.service.getbooks().subscribe(res => {
      this.user = res;
      this.dataSource = new MatTableDataSource(this.user);
      this.changeDetectorRefs.detectChanges();
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  recorddelete(id: string): void {
    alert(id);
    this.service.deleterecord(id).subscribe(
      data => {
        if (data) {
          // alert(data);
          alert("record deleted sucessfully");
          this.refresh();
        } else {
          alert("could not delete");
        }
      },
      err => {
        console.log(" Error" + JSON.stringify(err));
        alert("could not delete ! server problem" + err);
      }
    );
  }
}

import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { LibrarianService } from "../../services/librarian.service";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatTableDataSource
} from "@angular/material";
import { BookService } from "../../services/book.service";
import { HttpClient } from "@angular/common/http";
import { AddbooksComponent } from "../addbooks/addbooks.component";
import { Addbook } from "../../interface/addbook";
@Component({
  selector: "app-addbookpopup",
  templateUrl: "./addbookpopup.component.html",
  styleUrls: ["./addbookpopup.component.css"]
})
export class AddbookpopupComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    private bookser: BookService,
    private matdigref: MatDialogRef<AddbookpopupComponent>,
    public httpClient: HttpClient
  ) {}

  frm: FormGroup;

  ngOnInit() {
    this.frm = this.fb.group({
      name: [
        "",
        Validators.compose([
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(20)
        ])
      ],
      author: [
        "",
        Validators.compose([
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(20)
        ])
      ],
      publication: [
        "",
        Validators.compose([
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(20)
        ])
      ],
      price: ["", Validators.required]
    });
  }

  addbook() {
    this.bookser.addbooks(this.frm.value).subscribe(
      data => {
        console.log("Book Detail:" + JSON.stringify(data));
        if (data) {
          alert("Book added sucessfully");
        } else {
          alert("could not add");
        }
      },
      err => {
        console.log("Book Error" + JSON.stringify(err));
        alert("could not Add ! server problem");
      }
    );
  }

  onNoClick() {
    this.matdigref.close();
  }
  get val() {
    return this.frm.controls;
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddbookpopupComponent } from './addbookpopup.component';

describe('AddbookpopupComponent', () => {
  let component: AddbookpopupComponent;
  let fixture: ComponentFixture<AddbookpopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddbookpopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddbookpopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

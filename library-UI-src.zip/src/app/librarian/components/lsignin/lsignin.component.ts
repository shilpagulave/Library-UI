import { Component } from "@angular/core";
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { HttpResponse } from "@angular/common/http";
import { LibrarianService } from "../../services/librarian.service";
import { Router } from "@angular/router";
// import { RegistrationService } from 'src/app/students/services/registration.service';

@Component({
  selector: "app-lsignin",
  templateUrl: "./lsignin.component.html",
  styleUrls: ["./lsignin.component.css"]
})
export class LsigninComponent {
  constructor(
    private fb: FormBuilder,
    private labser: LibrarianService,
    private router: Router
  ) {}

  frm: FormGroup;

  ngOnInit() {
    this.frm = this.fb.group({
      email: ["", Validators.required],
      pass: ["", Validators.required]
    });
  }

  // librarianlogin() {
  // this.reg.sturegister(this.frm.value);
  // }
  librarianlogin() {
    this.labser.lablogin(this.frm.value).subscribe(
      function(labData: HttpResponse<any>) {
        console.log(labData.body);
        console.log(labData.headers.get("X-token"));

        sessionStorage.setItem("token", labData.headers.get("X-token"));

        //  this.route.navigate(['/navigation']);
      },
      err => {
        alert("could not signin");
        console.log(err);
      },
      () => {
        alert("Login successfull");
        this.router.navigate(["/librarian"]);
      }
    );

    console.log(this.frm.value);
  }
}

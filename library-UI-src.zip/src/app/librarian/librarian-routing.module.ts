import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { LibrariancontrolpanelComponent } from "./components/librariancontrolpanel/librariancontrolpanel.component";
import { LibrariandashboardComponent } from "./components/librariandashboard/librariandashboard.component";
import { AddbooksComponent } from "./components/addbooks/addbooks.component";
import { UserlistComponent } from "./components/userlist/userlist.component";
import { LogoutComponent } from "./components/logout/logout.component";
import { ProfileComponent } from "./components/profile/profile.component";
import { ChangepasswordComponent } from "./components/changepassword/changepassword.component";

const routes: Routes = [
  {
    path: "",
    component: LibrariancontrolpanelComponent,
    children: [
      { path: "librarian-dashboard", component: LibrariandashboardComponent },
      { path: "librarian-addbooks", component: AddbooksComponent },
      { path: "librarian-userlist", component: UserlistComponent },

      { path: "librarian-profile", component: ProfileComponent },
      { path: "librarian-changpassword", component: ChangepasswordComponent },
      { path: "librarian-logout", component: LogoutComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LibrarianRoutingModule {}

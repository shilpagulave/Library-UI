export interface Student {
  name: string;
  mobile: string;
  email: string;
  pass: string;
}

import { Injectable } from "@angular/core";
import { environment as env } from "../../../environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Student } from "../interface/student";
import { Observable } from "rxjs";
@Injectable({
  providedIn: "root"
})
export class RegistrationService {
  path = env.serverURL + "/student";
  constructor(private http: HttpClient) {}

  sturegister(student: Student): Observable<Student> {
    return this.http.post<Student>(this.path + "/create", student);
  }

  // stulogin(student: Student): Observable<Student> {
  //   return this.http.post<Student>(this.path + "/login", student);
  //   // return;
  // }

  stulogin(student: Student): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ "Content-Type": "application/json" }),
      observe: "response" as "response"
    };

    return this.http.post<Student>(this.path + "/login", student, httpOptions);
  }
}

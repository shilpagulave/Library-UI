import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { StudentcontrolpanelComponent } from "./components/studentcontrolpanel/studentcontrolpanel.component";
import { SdashboardComponent } from "./components/sdashboard/sdashboard.component";
import { SbooksComponent } from "./components/sbooks/sbooks.component";
import { SmybooksComponent } from "./components/smybooks/smybooks.component";
import { ProfileComponent } from "./components/profile/profile.component";
import { ChangepasswordComponent } from "./components/changepassword/changepassword.component";
import { SignoutComponent } from "./components/signout/signout.component";

const routes: Routes = [
  {
    path: "",
    component: StudentcontrolpanelComponent,
    children: [
      { path: "student-dashboard", component: SdashboardComponent },
      { path: "student-books", component: SbooksComponent },
      { path: "student-mybooks", component: SmybooksComponent },
      { path: "student-profile", component: ProfileComponent },
      { path: "student-changepass", component: ChangepasswordComponent },
      { path: "student-signout", component: SignoutComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentsRoutingModule {}

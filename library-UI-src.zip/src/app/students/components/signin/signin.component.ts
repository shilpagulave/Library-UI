import { Component } from "@angular/core";
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { RegistrationService } from "../../services/registration.service";
import { HttpResponse } from "@angular/common/http";
import { Router } from "@angular/router";

@Component({
  selector: "app-signin",
  templateUrl: "./signin.component.html",
  styleUrls: ["./signin.component.css"]
})
export class SigninComponent {
  constructor(
    private fb: FormBuilder,
    private reg: RegistrationService,
    private router: Router
  ) {}

  frm1: FormGroup;
  message;
  ngOnInit() {
    this.frm1 = this.fb.group({
      email: ["", Validators.required],
      pass: ["", Validators.required]
    });
  }

  studentlogin() {
    this.reg.stulogin(this.frm1.value).subscribe(
      function(studData: HttpResponse<any>) {
        console.log(studData.body);
        console.log(studData.headers.get("X-token"));

        sessionStorage.setItem("token", studData.headers.get("X-token"));

        //  this.route.navigate(['/navigation']);
      },
      err => {
        alert("could not signin");
        console.log(err);
      },
      () => {
        alert("Login successfull");
        this.router.navigate(["/students"]);
      }
    );

    console.log(this.frm1.value);
  }
  // this.reg.stulogin(this.frm.value).subscribe(
  //   data => {
  //     console.log("student:" + JSON.stringify(data));
  //     if (data) {
  //       alert("Login sucessfully");
  //     } else {
  //       alert("could not Login");
  //     }
  //   },
  //   err => {
  //     console.log("Login Error" + JSON.stringify(err));
  //     alert("could not Login ! server problem");
  //   }
  // );

  // console.log("called signin");
}

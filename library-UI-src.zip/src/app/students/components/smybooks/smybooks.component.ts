import { AfterViewInit, Component, OnInit, ViewChild } from "@angular/core";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTable } from "@angular/material/table";
import { SmybooksDataSource, SmybooksItem } from "./smybooks-datasource";

@Component({
  selector: "app-smybooks",
  templateUrl: "./smybooks.component.html",
  styleUrls: ["./smybooks.component.css"]
})
export class SmybooksComponent implements AfterViewInit, OnInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild(MatTable, { static: false }) table: MatTable<SmybooksItem>;
  dataSource: SmybooksDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = [
    "id",
    "name",
    "author",
    "publication",
    "language",
    "action"
  ];

  ngOnInit() {
    this.dataSource = new SmybooksDataSource();
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }
}

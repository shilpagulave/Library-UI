import { Component, OnInit, NgModule } from "@angular/core";
// import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { RegistrationService } from "../../services/registration.service";

@Component({
  selector: "app-signup",
  templateUrl: "./signup.component.html",
  styleUrls: ["./signup.component.css"]
})
export class SignupComponent implements OnInit {
  constructor(private fb: FormBuilder, private reg: RegistrationService) {}

  frm: FormGroup;

  ngOnInit() {
    this.frm = this.fb.group({
      name: ["", Validators.required],
      // address: ["", Validators.required],
      mobile: ["", Validators.compose([Validators.pattern[0 - 9]])],
      email: ["", Validators.required],
      pass: ["", Validators.required]
    });
  }
  register() {
    this.reg.sturegister(this.frm.value).subscribe(
      data => {
        console.log("student:" + JSON.stringify(data));
        if (data) {
          alert("register sucessfully");
        } else {
          alert("could not register");
        }
      },
      err => {
        console.log("Student Error" + JSON.stringify(err));
        alert("could not register ! server problem");
      }
    );
  }
  // clear() {
  //   this.frm.value.name = "";
  //   this.frm.value.address = "";
  //   this.frm.value.mobile = "";
  //   this.frm.value.email = "";
  // }
  // frm="";
}

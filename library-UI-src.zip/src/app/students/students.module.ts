import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { StudentsRoutingModule } from "./students-routing.module";
import { StudentcontrolpanelComponent } from "./components/studentcontrolpanel/studentcontrolpanel.component";
import { LayoutModule } from "@angular/cdk/layout";
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatButtonModule } from "@angular/material/button";
import { MatSidenavModule } from "@angular/material/sidenav";
import { MatIconModule } from "@angular/material/icon";
import { MatListModule } from "@angular/material/list";
// import { SignupComponent } from "./components/signup/signup.component";
// import { SigninComponent } from './components/signin/signin.component';
import { MatInputModule } from "@angular/material/input";
import { MatSelectModule } from "@angular/material/select";
import { MatRadioModule } from "@angular/material/radio";
import { MatCardModule } from "@angular/material/card";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { SdashboardComponent } from "./components/sdashboard/sdashboard.component";
import { MatGridListModule } from "@angular/material/grid-list";
import { MatMenuModule } from "@angular/material/menu";
import { SbooksComponent } from "./components/sbooks/sbooks.component";
import { MatTableModule } from "@angular/material/table";
import { MatPaginatorModule } from "@angular/material/paginator";
import { MatSortModule } from "@angular/material/sort";
import { SmybooksComponent } from "./components/smybooks/smybooks.component";
import { ProfileComponent } from "./components/profile/profile.component";
import { ChangepasswordComponent } from "./components/changepassword/changepassword.component";
import { SignoutComponent } from "./components/signout/signout.component";
// import { SignupComponent } from "./components/signup/signup.component";
// import { SigninComponent } from "./components/signin/signin.component";

@NgModule({
  declarations: [
    StudentcontrolpanelComponent,
    SdashboardComponent,
    SbooksComponent,
    SmybooksComponent,
    ProfileComponent,
    ChangepasswordComponent,
    SignoutComponent
  ],
  imports: [
    CommonModule,
    StudentsRoutingModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatCardModule,
    ReactiveFormsModule,
    MatGridListModule,
    MatMenuModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    FormsModule
  ]
})
export class StudentsModule {}

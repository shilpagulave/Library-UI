import { NgModule, Component } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./shared/components/home/home.component";
import { AboutComponent } from "./shared/components/about/about.component";
import { ContactComponent } from "./shared/components/contact/contact.component";
import { SignupComponent } from "./students/components/signup/signup.component";
import { SigninComponent } from "./students/components/signin/signin.component";
import { PagenotfoundComponent } from "./shared/components/pagenotfound/pagenotfound.component";
import { LsigninComponent } from "./librarian/components/lsignin/lsignin.component";
import { LragistrationComponent } from "./librarian/components/lragistration/lragistration.component";

const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "about", component: AboutComponent },
  { path: "contact", component: ContactComponent },

  {
    path: "librarian",
    loadChildren: () =>
      import("./librarian/librarian.module").then(mod => mod.LibrarianModule)
  },
  {
    path: "students",
    loadChildren: () =>
      import("./students/students.module").then(mod => mod.StudentsModule)
  },
  { path: "students-signin", component: SigninComponent },
  { path: "students-signup", component: SignupComponent },
  { path: "librarian-signin", component: LsigninComponent },
  { path: "librarian-signup", component: LragistrationComponent },
  { path: "**", component: PagenotfoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}

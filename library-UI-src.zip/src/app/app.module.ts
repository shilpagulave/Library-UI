import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HomeComponent } from "./shared/components/home/home.component";
import { AboutComponent } from "./shared/components/about/about.component";
import { ContactComponent } from "./shared/components/contact/contact.component";
import { HeaderComponent } from "./shared/components/header/header.component";
import { FooterComponent } from "./shared/components/footer/footer.component";
// module
import { ModulesModule } from "./modules/modules.module";
import { SignupComponent } from "./students/components/signup/signup.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { SigninComponent } from "./students/components/signin/signin.component";
import { PagenotfoundComponent } from "./shared/components/pagenotfound/pagenotfound.component";
import { LsigninComponent } from "./librarian/components/lsignin/lsignin.component";
import { MatCardModule } from "@angular/material/card";
import { MatRadioModule } from "@angular/material/radio";
import { MatSelectModule } from "@angular/material/select";
import { HttpClientModule } from "@angular/common/http";
import { MatFormFieldModule } from "@angular/material/form-field";
import { AddbookpopupComponent } from "./librarian/components/addbookpopup/addbookpopup.component";
import { MatIconModule } from "@angular/material/icon";
import { MatToolbarModule } from "@angular/material/toolbar";
import { LragistrationComponent } from "./librarian/components/lragistration/lragistration.component";
// import { MaterialModule } from "./modules/modules.module";
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    HeaderComponent,
    FooterComponent,

    // not a part of ng module - signup compo- import { NgModule } from "@angular/core";
    SignupComponent,
    SigninComponent,
    PagenotfoundComponent,
    LsigninComponent,
    AddbookpopupComponent,
    LragistrationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ModulesModule,
    FormsModule,
    ReactiveFormsModule,
    // MdCardModule
    MatCardModule,
    MatRadioModule,
    MatSelectModule,
    HttpClientModule,
    MatFormFieldModule,
    MatIconModule,
    MatToolbarModule
    // MaterialModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [AddbookpopupComponent]
})
export class AppModule {}

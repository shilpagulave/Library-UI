export const environment = {
  production: true,
  serverURL: "http://localhost:7777/api/v1"
};
